from pathlib import Path
import json, re, html, hashlib
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

FONTDIR=Path('/Users/aneeshwarrier/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype')
for name,file in [('CCSans','LiberationSans-Regular.ttf'),('CCSans-Bold','LiberationSans-Bold.ttf'),('CCSans-Italic','LiberationSans-Italic.ttf'),('CCSans-BoldItalic','LiberationSans-BoldItalic.ttf'),('CCMono','LiberationMono-Regular.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONTDIR/file)))
pdfmetrics.registerFontFamily('CCSans',normal='CCSans',bold='CCSans-Bold',italic='CCSans-Italic',boldItalic='CCSans-BoldItalic')

BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parents[1]
OUT=ROOT/'output/pdf/Salary_Constraint_Appendix.pdf'
REPORT=BASE/'report'
NAVY=colors.HexColor('#132a3c'); GRAY=colors.HexColor('#53616c'); LINE=colors.HexColor('#d7dee3'); PALE=colors.HexColor('#f2f5f7')
styles={
 'title':ParagraphStyle('title',fontName='CCSans-Bold',fontSize=31,leading=34,textColor=NAVY,spaceAfter=14),
 'sub':ParagraphStyle('sub',fontName='CCSans',fontSize=15,leading=20,textColor=GRAY,spaceAfter=16),
 'h1':ParagraphStyle('h1',fontName='CCSans-Bold',fontSize=21,leading=25,textColor=NAVY,spaceAfter=14),
 'h2':ParagraphStyle('h2',fontName='CCSans-Bold',fontSize=11.5,leading=15,textColor=NAVY,spaceBefore=12,spaceAfter=6),
 'body':ParagraphStyle('body',fontName='CCSans',fontSize=10.3,leading=14.4,textColor=NAVY,spaceAfter=9),
 'small':ParagraphStyle('small',fontName='CCSans',fontSize=8.8,leading=11.8,textColor=GRAY,spaceAfter=6),
 'cell':ParagraphStyle('cell',fontName='CCSans',fontSize=9,leading=12,textColor=NAVY),
 'th':ParagraphStyle('th',fontName='CCSans-Bold',fontSize=8.8,leading=11.5,textColor=colors.white),
 'formula':ParagraphStyle('formula',fontName='CCMono',fontSize=9.4,leading=14.5,textColor=NAVY,backColor=PALE,borderPadding=10,spaceBefore=5,spaceAfter=15),
 'quote':ParagraphStyle('quote',fontName='CCSans-Italic',fontSize=11,leading=16,textColor=NAVY,leftIndent=12,rightIndent=12,spaceBefore=8,spaceAfter=12),
}
SOURCES=[
 ('NBPA. Current Collective Bargaining Agreement','Effective July 1, 2023; current agreement landing page.','https://nbpa.com/cba'),
 ('NBA/NBPA. 2023 Collective Bargaining Agreement','June 28, 2023. Art. II sec. 13(d), printed p.61; sec.4(c), pp.25-26; UPC paragraph10.','https://imgix.cosmicjs.com/25da5eb0-15eb-11ee-b5b3-fbd321202bdf-Final-2023-NBA-Collective-Bargaining-Agreement-6-28-23.pdf'),
 ('NBA. CBA 101','November 2024. Cap, maximum salary, annual raises, incentives, renegotiations and BRI.','https://cms.nba.com/wp-content/uploads/sites/4/2024/11/2024-25-CBA-101.pdf'),
 ('Fantex. Free Writing Prospectus','January 27, 2015. Athlete brand contracts and valuation. SEC-filed issuer material.','https://www.sec.gov/Archives/edgar/data/1573683/000110465915004681/a15-1065_4fwp.htm'),
 ('Fantex. Free Writing Prospectus','May 21, 2014. Tracking stock, discretionary dividends and liquidity risk. SEC-filed issuer material.','https://www.sec.gov/Archives/edgar/data/1573683/000110465914040834/a14-6704_18fwp.htm'),
 ('Fantex. Dividend announcement','November 19, 2020. $2.1 million of declared dividends. Issuer press release.','https://fantex.com/downloads/FNTX_Divi_12_24.20_Release.pdf'),
 ('SEC. Exempt Offerings','Updated January 26, 2026. Registration or an available exemption required.','https://www.sec.gov/resources-small-businesses/exempt-offerings'),
 ('SEC Investor.gov. Types of Orders','Accessed October 7, 2026. Market, limit and stop-order distinctions.','https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/types-orders'),
 ('FINRA. Brokerage Accounts','Accessed October 7, 2026. Initial margin, maintenance margin and house requirements.','https://www.finra.org/investors/investing/investment-accounts/brokerage-accounts'),
 ('FINRA. Rule 4210','Accessed October 7, 2026. Maintenance margin; long and short treatment differs.','https://www.finra.org/rules-guidance/rulebooks/finra-rules/4210'),
 ('SEC. Key Points About Regulation SHO','Accessed October 7, 2026. Locate and close-out concepts; settlement discussion on this page is historical.','https://www.sec.gov/investor/pubs/regsho.htm'),
 ('SEC Investor.gov. New T+1 Settlement Cycle','March 27, 2024. Standard covered transactions move to T+1 on May 28, 2024.','https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins/new-t1-settlement-cycle-what-investors-need-know-investor-bulletin'),
 ('CME Group. Money Calculations for Futures and Options','November 10, 2015. Daily settlement variation in cash.','https://www.cmegroup.com/education/articles-and-reports/money-calculations-for-futures-and-options'),
 ('CME Group. Calculating Fair Value','Accessed October 7, 2026. Financing, dividends, time and futures basis.','https://www.cmegroup.com/trading/equity-index/fairvalue.html'),
 ('OCC/OIC. American-style and European-style options','March 2020. Exercise timing and European-style pricing convention.','https://prd-web.optionseducation.org/news/what-is-the-difference-between-american-style-and'),
 ('OCC/OIC. Equity vs. Index Options','Accessed October 7, 2026. Cash-settlement mechanics and multipliers.','https://prd-web.optionseducation.org/advancedconcepts/equity-vs-index-options'),
 ('NBA Communications. 2026-27 Salary Cap','June 30, 2026. Official release; 2026-27 cap is $164.961 million.','https://www.nba.com/news/nba-salary-cap-2026-27-season'),
]

story=[]; source_text=[]
def add(text, style='body'):
    story.append(Paragraph(text,styles[style])); source_text.append(re.sub('<[^>]+>','',text))
def p(text): add(text)
def h(text): add(text,'h2')
def note(text): add(text,'small')
def formula(text): add(html.escape(text),'formula')
def page(title, num, kicker):
    if story: story.append(PageBreak())
    add(f'RESEARCH NOTE {num:02d} / {kicker.upper()}','small');add(title,'h1')
def table(rows,widths):
    data=[[Paragraph(str(c),styles['th' if i==0 else 'cell']) for c in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,0),.5,NAVY),('LINEBELOW',(0,1),(-1,-1),.4,LINE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE])]))
    story.append(t);story.append(Spacer(1,10));source_text.extend([' | '.join(str(c) for c in row) for row in rows])

add('COURT CAPITAL','title')
add('NBA contract economics, hypothetical income valuation and market-mechanics research','sub')
note('Aneesh Warrier | Research prototype | October 7, 2026')
note('Developed with AI-assisted research and implementation. All player names and instrument terms are fictional. No actual money, player contracts, investment offering or live exchange.')
h('The central research question')
p('When does a player who is inexpensive for a team become expensive for an income investor? Court Capital separates on-court economic contribution, contractual salary receipts and a hypothetical claim price. The separation makes it possible to examine contract renewal risk, career uncertainty, cap growth and trading frictions without treating a box score as a dividend.')
h('What the prototype contributes')
table([['Layer','Decision the layer supports'],['Contract economics','Compare fixed salary obligations with uncertain future contracts and a cap-relative performance-value proxy.'],['Stochastic valuation','Evaluate a finite five-year paper income claim under declared assumptions; isolate price, distribution and terminal-value effects.'],['Market laboratory','Test how order execution, borrowing, margin, derivative carry and corporate actions change portfolio accounting.'],['Commercial evaluation','Assess research software as the initial product and identify unresolved rights and regulatory conditions for any real financial product.']],[110,394])
h('Evidence status')
p('NBA employment rules and general market conventions are sourced to primary documents. Career states, commercial terms, market liquidity and valuation inputs are hypothetical. Simulation results are conditional model outputs, not estimates validated against NBA history. The prototype is not a trained AI forecasting model and does not claim investment performance or a backtest.')
p('The most material legal finding is explicit: the NBA agreement restricts direct assignment of a player\'s compensation rights. The project therefore treats salary-linked units as an analytical counterfactual. It does not claim that an athlete consent form or a token removes this restriction. [1, 2]')
note('Reading guide: cash-flow definition (2), NBA constraints (3), methodology (4), model results (5), market mechanics (6-7), research and risks (8), business pitch (9), validation (10), sources (11).')

page('Define the cash flow before pricing it',2,'financial architecture')
p('A claim on salary is economically different from ownership of a person, a team or a share of NBA revenue. This prototype asks what a narrowly defined, hypothetical participation in eligible receipts would be worth, assuming the participation existed. Establishing an enforceable right is outside the simulation.')
table([['Term','Research definition'],['Claim window','Five years. No perpetual income claim and no automatic claim on the player\'s entire career.'],['Participation','A declared fraction of modeled eligible income. The fraction is a scenario input, not an existing agreement.'],['Units','A fixed denominator allocates the modeled receipts. Unit count is not diluted unless a separately documented corporate action changes it.'],['Eligible receipts','Modeled salary receipts within the window, net of declared receipt adjustments and fees. Endorsements, taxes, insurance and post-career earnings require separate assumptions.'],['End of term','Claims expire with no principal redemption. A final distribution is a cash flow; expiration itself does not return the original purchase price.']],[110,394])
formula('distribution per unit = participation x eligible receipts x (1 - fee) / units')
formula('value per unit = sum_t E[distribution_t] / (1 + discount rate)^t')
p('The valuation is an expected discounted cash-flow estimate. A purchaser\'s return also depends on the price paid. Buying at a lower price can improve the modeled return without improving the player\'s career. A projected rise in value is an unrealized change, not a distribution. Cash received partly compensates the holder for an asset that is running down toward expiry.')
h('Two ledgers must remain distinct')
p('<b>Team ledger.</b> A cap-relative estimate of performance value less salary cost measures contract efficiency for a roster. <b>Income ledger.</b> Protected receipts plus uncertain next-contract receipts determine the hypothetical claim\'s cash-flow base. A rising player on a cheap contract can be attractive on the first ledger and low-yielding on the second. An expensive veteran can have the reverse profile.')
note('Analytical definitions in this page are original prototype design choices, not NBA contract terms or representations that participation rights are transferable.')

page('NBA rules create the contract boundary',3,'institutional facts')
h('Direct compensation assignment is restricted')
add('"No player shall assign or otherwise transfer to any third party his right to receive Compensation from the Team under his Uniform Player Contract."','quote')
note('2023 NBA/NBPA CBA, Article II, Section 13(d), printed page 61 (PDF page 85). [2]')
p('This restriction is central to product selection. A simulation can study a counterfactual claim without asserting that the claim may be issued. A separate post-receipt arrangement would need its own specialist analysis; it is not established here as a workaround.')
table([['Rule','Model implication'],['Salary maximums','General initial-season levels are 25%, 30% or 35% of cap by service band, with exceptions. A larger cap does not automatically reprice every existing salary.'],['Scheduled raises','Typical limits use 5% or 8% of first-year salary. Later salary schedules must not be mistaken for annual compounding at those rates.'],['Cap path','Current rules limit annual cap growth to 0%-10%. This is a modeling boundary under the current agreement, not an eternal economic law.'],['Renegotiation','Generally requires cap room, a four-plus-year contract and the third signing anniversary. It increases existing-term salary; unrestricted restructuring is not assumed.'],['Injury and trades','Applicable salary protection may preserve payments despite basketball injury; trading normally transfers the existing contract. Future earning power can still change.']],[110,394])
note('NBA CBA 101, November 2024, printed pp.1, 9-14; full CBA Article II Section 4(c) and UPC paragraph 10. [2, 3]')
h('Precedent changes the novelty claim')
p('Fantex offered issuer tracking stock linked to athlete brand-income contracts, with upfront payments and defined future participation. Its 2014 disclosures distinguished issuer ownership from direct athlete ownership and made dividends discretionary. An issuer announcement later reported $2.1 million of declared dividends in November 2020. These precedents establish prior athlete-income financial products, not NBA permission or a validated template for this project. [4-6]')
p('The project\'s contribution is the integration of contract constraints, dual valuation and market accounting. It does not claim to invent the idea of athlete-linked investment.')

page('An explicit model of uncertain cash flows',4,'methodology')
p('The stochastic layer estimates scenario distributions rather than observed frequencies. Every numerical prior should remain inspectable and adjustable. The purpose is to learn which assumptions determine an outcome, not to convert subjective probabilities into apparent certainty.')
table([['Component','Required modeling distinction'],['Contract states','Separate already-contracted years from renewal years. Apply protection to existing obligations and condition renewal terms on the hypothetical career state.'],['Shared uncertainty','Use the same league cap path across players within a draw. Diversification cannot eliminate a common revenue or cap shock.'],['Individual uncertainty','Model career progression, availability and retention with disclosed assumptions. No private health information or actual individual prognosis is used.'],['Valuation','Keep the investor discount rate separate from a derivative-pricing rate. Price relative to participation and units so normalization cannot create value.'],['Measurement','Report means, medians and downside quantiles together. Include purchase-price sensitivity and distinguish cash yield from total return.']],[112,392])
h('Statistical interpretation')
p('A larger Monte Carlo sample reduces random numerical noise conditional on the assumptions. It does not make those assumptions empirically correct. Percentiles summarize simulated scenarios; they are not confidence intervals for a player\'s real career. Ranking correlations across fictional cases are descriptive properties of the chosen examples, not estimates for the NBA population.')
h('A credible empirical extension')
p('A later study would freeze a historical information date, assemble legally usable contract and performance data, and predict outcomes after that date. Evaluation should use rolling time splits and exclude all information unavailable at the forecast date. Compare a simple age/experience/contract baseline with richer models, then assess calibration, mean absolute error and interval coverage by career stage. No such historical validation has been completed for this prototype.')
h('Practical inference standard')
p('If rankings reverse under modest changes to fees, contract retention or discount rates, report the reversal as decision uncertainty. If a conclusion holds only because an input was chosen to force it, the conclusion is illustrative. Useful evidence is an auditable sensitivity boundary, not a high simulated return.')

page('Conditional model results',5,'simulation output')
MODEL_SECTION=[]
# Filled from verified model.json by a compact adapter after the model artifact is available.

page('Spot trading, borrowing and the ledger',6,'market mechanics')
p('The paper market is an accounting and execution laboratory. Synthetic quotes, market depth and time steps let a reviewer reproduce state changes. They are not evidence that buyers, lenders or counterparties would exist for a real athlete-linked claim.')
table([['Mechanic','Prototype convention and boundary'],['Orders and spread','Market orders consume finite displayed depth; limits respect price and available size. FIFO priority and bid/ask spreads are simulation rules. Limits can remain unfilled. [8]'],['Settlement','Immediate local T+0 updates simplify the ledger. Most covered U.S. securities trades use T+1 in production; no clearinghouse or settlement guarantee is simulated. [12]'],['Long margin','50% initial equity and 30% maintenance are declared house assumptions. Regulation T generally implies 50% initial for marginable stock; FINRA\'s general long minimum is 25%. Actual eligibility varies. [9, 10]'],['Shorting','Finite locate inventory, restricted sale proceeds, daily borrow costs and distribution liabilities are modeled. A successful local locate is not a real securities loan. [11]'],['Controls','A 10% order-price collar rejects distant limits. Any simulated halt or liquidation rule is a lab rule, not the national-market circuit-breaker or Regulation SHO rule set.'],['Cash and marks','Separate free cash, restricted proceeds, debt, position value, realized P&L and accrued charges. Reconcile equity after every event; proceeds from shorting are not new profit.']],[112,392])
h('Why accounting details change the conclusion')
p('An apparently profitable forecast can lose money after spread, fees, financing and delayed fills. Borrow can disappear when a price gap is largest. Margin can force liquidation before a long-run thesis is realized. The model therefore treats funding and execution as constraints on a strategy, not deductions appended after the result.')
p('A local liquidation uses a disclosed stylized adverse-price auction. It does not prove that a stressed market would supply that depth. A production system would require order surveillance, clearing, reconciliation, capital and default-management arrangements beyond this prototype.')
note('Primary sources describe general market mechanics. They do not classify or authorize the hypothetical Court Capital instruments.')

page('Derivatives and corporate-action consistency',7,'instrument mechanics')
h('Futures: exposure without purchasing the asset')
p('A futures position carries a signed quantity and cash variation as its settlement mark changes. The reference convention is financing cost less distributions before expiry; actual traded prices need not equal theoretical value. Futures holders do not receive the underlying\'s distribution directly. [13, 14]')
formula('future reference = (spot - PV(distributions before expiry)) x exp(r x T)')
formula('cash variation = signed quantity x (new settlement - prior settlement)')
p('The prototype uses scheduled discrete distributions, daily settlement and final convergence to spot. Margin secures exposure rather than paying the full purchase price. Collateral requirements and adverse variation must both be funded; reporting only mark-to-market profit hides liquidity demand.')
h('Options: a bounded long-premium exercise')
p('The lab supports long European-style calls and puts with full premium paid, an explicit pricing rate and volatility, and a declared 100-unit multiplier. Expiry pays the cash intrinsic value. European exercise occurs at expiry; this differs from many U.S. equity options. [15, 16]')
formula('call expiry cash = contracts x 100 x max(spot - strike, 0)')
formula('put expiry cash  = contracts x 100 x max(strike - spot, 0)')
p('A Black-Scholes-style continuous-yield approximation is a teaching reference. Its assumptions are restrictive for an illiquid, discontinuous, finite-life claim. Synthetic price paths are a separate stylized process, not jointly arbitrage-free with the DCF. The option price is not an executable hedge cost. Option writing and early exercise are outside this version.')
h('Corporate actions must preserve economics')
p('A modeled distribution credits a long holder and debits a short holder while lowering the reference price. This is wealth-neutral only when the $0.01 simulated price floor does not bind. A split changes quantity and price reciprocally. Splits are rejected while derivatives or resting orders remain open to avoid incorrect adjustments. The five-year income claim expires with no principal repayment.')
note('Pricing-rate and margin percentages in the implementation are teaching inputs, not quoted financing offers or empirically calibrated requirements.')

page('Research questions, risks and ethics',8,'falsifiable agenda')
table([['Question','Observation that could reject the hypothesis'],['Does cap efficiency predict income attractiveness?','On a frozen empirical sample, rank correlation is weak or unstable after purchase-price and contract-stage controls.'],['Does diversification reduce downside?','Shared cap or liquidity stress leaves a portfolio\'s downside close to concentrated exposures after costs.'],['Do richer performance inputs improve forecasting?','A simple age/contract baseline matches or outperforms a richer model in time-separated holdouts.'],['Does public enthusiasm create a pricing premium?','Observed prices or stated willingness to pay do not depart from disclosed income valuation after uncertainty and fees.'],['Does funding dominate a good forecast?','A funded strategy retains its advantage across borrow, spread and margin sensitivity tests; then the funding-risk hypothesis weakens.'],['Can transparency reduce selection risk?','Additional verifiable disclosure fails to narrow valuation dispersion or improve calibration in a consent-based study.']],[225,279])
h('Risks that should remain visible')
p('<b>Adverse selection.</b> Athletes who expect lower future income might be more willing to sell participation. A model that assumes a random issuer pool understates this potential lemons premium. <b>Liquidity.</b> Quoted values are not liquidation proceeds. <b>Model risk.</b> Renewal probabilities, fee burdens and discount rates may dominate player performance. <b>Market integrity.</b> Thin float, hype, wash trading and coordinated misinformation could overwhelm fundamental pricing.')
p('<b>Player welfare and privacy.</b> Investors receive no influence over playing time, training, medical decisions or employment choices. Do not solicit nonpublic medical records or trade on material nonpublic health information. Fictional profiles in this version avoid personalized health predictions. A future data project needs lawful data rights, purposeful minimization, provenance and correction processes.')
p('<b>Controls to evaluate.</b> Consider position limits, restricted-person lists, scheduled disclosure windows, surveillance, volatility interruptions and complaint procedures. These are proposed governance requirements. The local price collar is not evidence that a full market-integrity program exists.')

page('Business pitch: contract-risk research first',9,'commercial thesis')
p('<b>Court Capital is a research workspace for understanding how sports contracts convert performance uncertainty into financial exposure.</b> Its first commercial hypothesis is software and analytical tooling for sports-finance research, training and decision support. A consumer investment venue is not the initial product.')
table([['Element','Specific proposition'],['User and problem','Sports-finance analysts, agents, finance educators and research teams need a consistent way to separate contract protection, cap efficiency, future earnings and funding risk. This need is a hypothesis to validate, not a proven market survey.'],['Initial product','A contract-risk workbench with transparent assumptions, scenario comparisons, audit-ready exports and a paper-market lab. Recruiters can inspect the full analytical chain rather than a static performance ranking.'],['Differentiation','A common cash-flow definition across team value, income valuation, simulated execution, margin and derivatives. Source-linked CBA constraints remain part of the product logic.'],['Revenue hypothesis','Institutional subscriptions, education licenses and scoped research work. No securities transaction fees are assumed in the first product; no willingness-to-pay evidence has been collected.'],['Validation milestones','Interview prospective users; reproduce a real historical contract study with licensed public data; test task completion and explanation quality; seek paid design partners only after usefulness is demonstrated.'],['Decision to continue','Continue if users can make a concrete decision faster and can explain which assumptions drive it. Stop or narrow the product if the workbench duplicates existing tools without measurable analytical benefit.']],[112,392])
h('Any financial-issuance pathway remains conditional')
p('A future real-income product would first require an enforceable right compatible with the CBA, willing player partners, specialist securities and derivatives analysis, appropriate intermediaries and permissions, transparent disclosures, and credible servicing and liquidity arrangements. SEC registration or a valid exemption is a separate gate. This document establishes none of those conditions. [2, 7]')
h('Recruiter-facing demonstration')
p('Explain a ranking reversal between the team and income ledgers. Change a renewal assumption, inspect the valuation range, submit a limit order, inspect an unfilled balance, and apply a funding shock. The demonstration shows financial judgment, model discipline and implementation capability without claiming that simulated profits are investment results.')

page('Validation, reproducibility and scope',10,'audit trail')
VALIDATION_SECTION=[]

page('Primary sources and provenance',11,'references')
note('All links accessed October 7, 2026. Source dates are publication dates where available. NBA and financial-market sources support institutional facts; fictional probabilities and product terms remain prototype assumptions. SEC-filed Fantex materials are issuer statements, not SEC endorsement.')
for i,(title,desc,url) in enumerate(SOURCES,1):
    add(f'<b>[{i}] <link href="{html.escape(url,quote=True)}" color="#165d89">{html.escape(title)}</link>.</b> {html.escape(desc)}','small')
note('Reproduction note: the local bundle contains model inputs, generated output, market-engine source and test scripts. No live NBA data feed, player participation, trained AI model or historical investment track record is represented.')

def footer(c,doc):
    c.saveState();w,h=doc.pagesize
    c.setStrokeColor(LINE);c.setLineWidth(.5);c.line(54,44,w-54,44)
    c.setFont('CCSans',8);c.setFillColor(GRAY)
    c.drawString(54,30,'COURT CAPITAL  |  Fictional research instruments  |  No actual money')
    c.drawRightString(w-54,30,f'{doc.page:02d}')
    c.restoreState()

def replace_section(title,items):
    start=next(i for i,f in enumerate(story) if isinstance(f,Paragraph) and f.text==title)+1
    end=next(i for i in range(start,len(story)) if isinstance(story[i],PageBreak))
    story[start:end]=items

def para(text,style='body'):return Paragraph(text,styles[style])

def build():
    model_path=BASE/'data/model.json'
    if not model_path.exists():raise SystemExit('Model output required before final PDF build: '+str(model_path))
    m=json.loads(model_path.read_text()); a=m['assumptions']; assets=m['assets']; port=m['portfolio']
    def tbl(rows,widths):
        data=[[para(str(c),'th' if i==0 else 'cell') for c in row] for i,row in enumerate(rows)]
        t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,1),(-1,-1),.4,LINE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE])]))
        return t
    rows=[['Fictional case','DCF/unit','P05-P95 DCF','Contracted PV','Cap surplus*']]
    for x in assets:rows.append([x['ticker'],f"${x['fair_value_per_unit']:.2f}",f"${x['pv_p05']:.2f}-${x['pv_p95']:.2f}",f"{100*x['contracted_pv_share']:.1f}%",f"${x['conceptual_cap_surplus']/1e6:+.1f}m"])
    results=[
      para(f"{m['draws']:,} paired scenario draws; seed {m['seed']}. Six fictional archetypes share cap and demand factors. Values use 1% participation, 100,000 units, a 12% assumed discount rate and four equal quarterly payments per modeled year."),
      tbl(rows,[91,76,118,107,112]),Spacer(1,9),
      para('*Cap surplus is an assumed performance-cap-value proxy less current salary, not observed wins, incremental revenue or a calibrated valuation. P05-P95 denotes scenario percentiles, not confidence limits.','small'),
      para('A concrete ranking reversal','h2'),
      para(f"RISE has the largest assumed cap surplus (${assets[0]['conceptual_cap_surplus']/1e6:.1f}m) but a ${assets[0]['fair_value_per_unit']:.2f} income-unit DCF. ANCHOR has only ${assets[2]['conceptual_cap_surplus']/1e6:.1f}m of assumed cap surplus but a ${assets[2]['fair_value_per_unit']:.2f} DCF; {100*assets[2]['contracted_pv_share']:.1f}% comes from currently contracted years. The ordering follows different cash-flow questions, not superior forecasting."),
      para('Portfolio downside remains material','h2'),
      para(f"At a $10,000 equal-dollar allocation purchased at each case's mean DCF, simulated discounted funding-loss VaR95 is {100*port['funding_loss_var95']:.2f}% and ES95 is {100*port['funding_loss_es95']:.2f}%. Funding loss equals 1 minus discounted receipts divided by cost. These are five-year discounted cash-flow shortfalls, not one-day trading VaR or observed portfolio losses."),
      tbl([['Paired counterfactual','Portfolio mean-PV change'],['Injury before every renewal',f"{100*m['stress_tests']['injury_before_renewal']['equal_dollar_portfolio_pv_change']:+.2f}%"],['Zero cap growth',f"{100*m['stress_tests']['zero_cap_growth']['equal_dollar_portfolio_pv_change']:+.2f}%"],['Discount rate 12% to 14%',f"{100*m['stress_tests']['discount_rate_plus_200bp']['equal_dollar_portfolio_pv_change']:+.2f}%"]],[300,204]),Spacer(1,8),
      para('The mean discounted-value ratio is 1 by construction because the purchase price equals mean DCF. The 12% IRR of expected cash flows restates the discount assumption; it is not evidence of achievable return.','small'),
    ]
    replace_section('Conditional model results',results)
    validate=[
      para('Verified economic-model checks','h2'),
      para('Twelve automated economic-model tests passed on October 7, 2026. They cover seeded reproducibility, bounded cap growth, nonnegative finite cash flows, service-based renewal limits, noncompounding salary raises, protected-pay invariance to injury, absorbing collection failure, quarterly timing by hand calculation, rate monotonicity, flat-cap behavior, equal-dollar value reconciliation and the expected-cash-flow IRR identity.'),
      para('These checks verify specified mathematical invariants. They do not establish accurate career probabilities, enforceable rights, legal eligibility, market liquidity or profitable forecasting.'),
      para('Inputs that materially govern the result','h2'),
      tbl([['Input','Declared convention'],['Starting cap / growth',f"${a['base_cap']/1e6:.3f}m [17]; triangular annual growth with 0% minimum, 6% mode and 10% maximum."],['Receipts / servicing','5% recurring collection-friction haircut, then 2% collection fee. The haircut is not tax or the NBA escrow rule.'],['Collection failure','0.5% annual absorbing failure of the hypothetical collection vehicle; subsequent distributions become zero. Distinct from athlete injury.'],['Claim and rate','Five years; 1% participation; 100,000 units; zero terminal principal; 4% base rate plus 8% assumed risk premium.'],['Beyond the agreement','The final modeled 2030-31 season extends beyond the current CBA. Continued growth bounds are assumed; the possible 2028-29 opt-out is not modeled.']],[112,392]),Spacer(1,8),
      para('Reproducibility and attribution','h2'),
      para('The market engine separately passed 21 tests covering cash and short ledgers, finite order depth, FIFO limits, collateral reservation, carry, futures variation and expiry, option parity and Greeks, splits, borrow recall, insolvency and finite claim expiry. The project includes both test suites, seeded model inputs, compressed scenario draws and primary-source metadata. These checks are distinct from empirical validation.'),
      para('Aneesh Warrier is the project author. Research, coding and document production used AI assistance. No machine-learning training, proprietary dataset, player partnership, consent-based experiment or historical strategy backtest is claimed. Market-mechanics realism and career-model validation are distinct work streams.'),
    ]
    replace_section('Validation, reproducibility and scope',validate)
    OUT.parent.mkdir(parents=True,exist_ok=True)
    doc=SimpleDocTemplate(str(OUT),pagesize=(612,792),leftMargin=54,rightMargin=54,topMargin=49,bottomMargin=61,title='Court Capital | Research and Pitch',author='Aneesh Warrier',subject='Fictional NBA contract economics and market mechanics research prototype')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    from pypdf import PdfReader
    reader=PdfReader(str(OUT));text='\n\n'.join(f'PAGE {i+1}\n'+(p.extract_text() or '') for i,p in enumerate(reader.pages))
    (REPORT/'Salary_Constraint_Appendix.txt').write_text(text)
    (REPORT/'salary_sources.json').write_text(json.dumps([{'id':i,'title':t,'description':d,'url':u} for i,(t,d,u) in enumerate(SOURCES,1)],indent=2))
    print(json.dumps({'pdf':str(OUT),'pages':len(reader.pages),'bytes':OUT.stat().st_size,'model_sha256':hashlib.sha256(model_path.read_bytes()).hexdigest(),'link_annotations':sum(len(p.get('/Annots',[])) for p in reader.pages)},indent=2))

if __name__=='__main__':build()
