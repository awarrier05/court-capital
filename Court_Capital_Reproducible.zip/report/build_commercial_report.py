from pathlib import Path
import json, re, html, hashlib
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

FONTDIR=Path('/Users/aneeshwarrier/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype')
for name,file in [('CCSans','LiberationSans-Regular.ttf'),('CCSans-Bold','LiberationSans-Bold.ttf'),('CCSans-Italic','LiberationSans-Italic.ttf'),('CCSans-BoldItalic','LiberationSans-BoldItalic.ttf'),('CCMono','LiberationMono-Regular.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONTDIR/file)))
pdfmetrics.registerFontFamily('CCSans',normal='CCSans',bold='CCSans-Bold',italic='CCSans-Italic',boldItalic='CCSans-BoldItalic')

BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parents[1]
OUT=ROOT/'output/pdf/Court_Capital_Research_and_Pitch.pdf'
REPORT=BASE/'report'
NAVY=colors.HexColor('#132a3c'); GRAY=colors.HexColor('#53616c'); LINE=colors.HexColor('#d7dee3'); PALE=colors.HexColor('#f2f5f7')
styles={
 'title':ParagraphStyle('title',fontName='CCSans-Bold',fontSize=31,leading=34,textColor=NAVY,spaceAfter=14),
 'sub':ParagraphStyle('sub',fontName='CCSans',fontSize=15,leading=20,textColor=GRAY,spaceAfter=16),
 'h1':ParagraphStyle('h1',fontName='CCSans-Bold',fontSize=21,leading=25,textColor=NAVY,spaceAfter=14),
 'h2':ParagraphStyle('h2',fontName='CCSans-Bold',fontSize=11.5,leading=15,textColor=NAVY,spaceBefore=12,spaceAfter=6),
 'body':ParagraphStyle('body',fontName='CCSans',fontSize=10.3,leading=14.4,textColor=NAVY,spaceAfter=9),
 'small':ParagraphStyle('small',fontName='CCSans',fontSize=8.8,leading=11.8,textColor=GRAY,spaceAfter=6),
 'cell':ParagraphStyle('cell',fontName='CCSans',fontSize=9,leading=12,textColor=NAVY),
 'th':ParagraphStyle('th',fontName='CCSans-Bold',fontSize=8.8,leading=11.5,textColor=colors.white),
 'formula':ParagraphStyle('formula',fontName='CCMono',fontSize=9.4,leading=14.5,textColor=NAVY,backColor=PALE,borderPadding=10,spaceBefore=5,spaceAfter=15),
 'quote':ParagraphStyle('quote',fontName='CCSans-Italic',fontSize=11,leading=16,textColor=NAVY,leftIndent=12,rightIndent=12,spaceBefore=8,spaceAfter=12),
}
SOURCES=[
('NBA/NBPA. 2023 Collective Bargaining Agreement','June 28, 2023. Art.II sec.13(d), p.61; Art.XIII secs.1-2, pp.339-340; Art.XXXVII, p.426.','https://imgix.cosmicjs.com/25da5eb0-15eb-11ee-b5b3-fbd321202bdf-Final-2023-NBA-Collective-Bargaining-Agreement-6-28-23.pdf'),
('NBPA. PLYRS UNTD launch','June 22, 2026. Collective player commercial brand.','https://nbpa.com/news/plyrs-untd-nbpa-launches-new-commercial-brand-to-amplify-collective-player-influence'),
('THINK450. Licensing','NBPA group commercial and sponsorship licensing.','https://www.think450.com/licensing'),
('NBA. Terms of Use','NBA/team intellectual property and commercial-use conditions.','https://www.nba.com/termsofuse'),
('NBPA. Fanatics Collectibles, NBA and NBPA partnership','2025. Example of distinct league and player licensing participants.','https://nbpa.com/news/fanatics-collectibles-nba-and-nbpa-launch-multiyear-partnership-to-elevate-the-collector-experience'),
('Fantex. SEC-filed free writing prospectus','January 27, 2015. Athlete brand-income participation precedent.','https://www.sec.gov/Archives/edgar/data/1573683/000110465915004681/a15-1065_4fwp.htm'),
('Fantex. SEC-filed free writing prospectus','May 21, 2014. Issuer tracking shares, dividends and risks.','https://www.sec.gov/Archives/edgar/data/1573683/000110465914040834/a14-6704_18fwp.htm'),
('Vestible Assets. Annual report on Form 1-K','Year ended December 31, 2025. Athlete income and team financing series; issuer disclosures.','https://www.sec.gov/Archives/edgar/data/1984345/000149315226025042/partii.htm'),
('Finlete Funding. Form C attachment','2025 filing. Athlete future-earnings participation and related promotional rights.','https://www.sec.gov/Archives/edgar/data/2010670/000201067025000006/C1.pdf'),
('Socios. Equity Token','Current product page describes planned club-equity product, not available for investment at access.','https://www.socios.com/socios-equity-token/'),
('SEC. Exempt Offerings','Updated January 26, 2026. Registration and exemption framework.','https://www.sec.gov/resources-small-businesses/exempt-offerings'),
('SEC. Regulation A','Reviewed November 14, 2024. Tier 2 limits, audited financial statements and reporting.','https://www.sec.gov/resources-small-businesses/exempt-offerings/regulation'),
('SEC. Regulation Crowdfunding','Current overview. Registered intermediary, offering limit and general one-year resale restriction.','https://www.sec.gov/resources-small-businesses/exempt-offerings/regulation-crowdfunding'),
('SEC. Alternative Trading System List','Current overview. Broker-dealer registration and Form ATS do not constitute SEC approval.','https://www.sec.gov/foia/frequently-requested-documents/alternative-trading-system-ats-list'),
('SEC. Guide to Broker-Dealer Registration','ATS naming restriction and operational classification.','https://www.sec.gov/about/divisions-offices/division-trading-markets/division-trading-markets-compliance-guides/guide-broker-dealer-registration'),
('SEC Investor.gov. Types of Orders','Market and limit orders; execution and price distinctions.','https://www.investor.gov/introduction-investing/investing-basics/how-stock-markets-work/types-orders'),
('FINRA. Brokerage Accounts','Initial and maintenance margin; house requirements.','https://www.finra.org/investors/investing/investment-accounts/brokerage-accounts'),
('FINRA. Rule 4210','Long and short maintenance requirements differ.','https://www.finra.org/rules-guidance/rulebooks/finra-rules/4210'),
('SEC. Regulation SHO key points','Locate and close-out concepts; historical settlement discussion is not used.','https://www.sec.gov/investor/pubs/regsho.htm'),
('SEC Investor.gov. T+1 settlement','March 27, 2024. Covered U.S. securities transactions move to T+1 on May 28, 2024.','https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins/new-t1-settlement-cycle-what-investors-need-know-investor-bulletin'),
('CME. Money Calculations for Futures and Options','November 10, 2015. Cash settlement variation.','https://www.cmegroup.com/education/articles-and-reports/money-calculations-for-futures-and-options'),
('CME. Calculating Fair Value','Financing, distributions and futures basis.','https://www.cmegroup.com/trading/equity-index/fairvalue.html'),
('OCC/OIC. American and European options','March 2020. European exercise at expiry.','https://prd-web.optionseducation.org/news/what-is-the-difference-between-american-style-and'),
('OCC/OIC. Equity vs. Index Options','Cash settlement conventions and multipliers.','https://prd-web.optionseducation.org/advancedconcepts/equity-vs-index-options'),
]
m=json.loads((BASE/'data/commercial_model.json').read_text()); a=m['assumptions']; assets=m['assets']; port=m['portfolio']; sens=m['sensitivities']; biz=m['platform_business']; b=biz['assumptions']
story=[]
def add(text,style='body'):story.append(Paragraph(text,styles[style]))
def p(text):add(text)
def h(text):add(text,'h2')
def note(text):add(text,'small')
def formula(text):
    story.append(Spacer(1,8))
    add(html.escape(text).replace('\n','<br/>'),'formula')
def page(title,n,kicker):
    if story:story.append(PageBreak())
    add(f'BUSINESS & RESEARCH NOTE {n:02d} / {kicker.upper()}','small');add(title,'h1')
def table(rows,widths):
    data=[[Paragraph(str(c),styles['th' if i==0 else 'cell']) for c in row] for i,row in enumerate(rows)]
    t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),NAVY),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,1),(-1,-1),.4,LINE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE])]))
    story.append(t);story.append(Spacer(1,10))

add('COURT CAPITAL','title')
add('Player Enterprise Exchange<br/>Business architecture and financial feasibility','sub')
note('Aneesh Warrier | October 7, 2026 | Developed with AI-assisted research and implementation')
p('<b>A commercial platform for financing and evaluating businesses built around licensed athlete brands.</b> The proposed issuer sells equity in a defined commercial operation. Sponsorships, merchandise, content and events generate revenue; operating cash can support distributions. Basketball performance matters only to the extent that it changes commercial demand.')
h('The product thesis')
p('Athlete brands can attract attention without providing a consistent way to trace attention into investor cash flow. Court Capital would connect a rights register, signed commercial contracts, sales economics and financial reporting to a transparent valuation. The advantage to test is the quality of that evidence chain, rather than a proprietary score that turns a good game into a dividend.')
table([['Participant','Proposed economic reason to participate'],['Player / brand owner','Finance a defined five-year commercial program; receive negotiated license and service payments; preserve ownership of underlying personal brand rights.'],['Brands and rights owners','Buy identifiable sponsorship inventory and receive licensed use payments where authorized. League or team participation is optional and requires separate agreements.'],['Investor','Own venture equity with disclosed expenses, governance and cash distributions; accept commercial, selection and liquidity risk.'],['Court Capital','Earn servicing revenue for operating and reporting infrastructure. A future securities venue would use appropriately authorized partners.']],[110,394])
h('What is built, and what remains to prove')
p(f'The prototype models six fictional ventures across {m["draws"]:,} scenarios, reconciles quarterly cash and tests financing and market mechanics. It does not establish real customer demand, license availability, a legally eligible offering, a trained AI model or investment returns. The salary-linked concept is retained separately as a constraint appendix.')
note('The subtitle is a conceptual project descriptor. An ATS may not call itself an exchange; any operating venue and brand require separate review. [15] No actual money, issuer, player agreement or live investment offering is represented.')

page('Define the issuer and the rights',2,'structure')
p('The reference structure separates the player\'s brand owner from the company financed by investors. A player-controlled parent licenses specified commercial rights to a five-year operating issuer. The issuer contracts with customers, collects revenue and pays costs. Investors hold equity in that issuer, not the athlete, team, league or employment contract.')
table([['Term','Candidate design and modeling treatment'],['Licensed asset','Enumerated categories, geography, media, deliverables, exclusivity and five-year term. Existing endorsement conflicts, sublicensing, termination and post-term inventory require agreement.'],['Reference capitalization','100,000 ordinary equity units represent 100% of the modeled issuer. The player retains underlying IP through the separate licensor, not residual issuer equity in this reference case.'],['Player compensation','An upfront license payment plus 25% of gross commercial revenue for ongoing license/services. Both are explicit assumptions; neither is a negotiated market rate.'],['Use of proceeds','Operating reserve, 2% issuance fee, then residual upfront license payment. A negative residual means the modeled financing cannot fund the stated reserve.'],['End of term','License expires; after modeled operations, actual remaining cash is distributed once. No terminal IP multiple, guaranteed principal or assumed license renewal.']],[115,389])
h('What the player keeps')
p('The licensed categories and duration bound the transaction. Playing, training, medical and employment decisions remain outside investor control. The underlying brand owner retains rights not expressly licensed. Keeping a player equity stake in the issuer is a possible alternative, but it requires a new cap table, proceeds allocation and governance model; it is not silently assumed here.')
h('NBA contract boundary')
p('CBA Article II section 13(d), printed page 61, restricts transferring compensation rights under the player contract. This design instead studies commercial-company equity. Article XIII sections 1-2, printed pages 339-340, also addresses disguised compensation and player/team arrangements. Commercial labels do not establish compliance. [1]')
note('Ordinary equity is a proposed instrument form, not a legal classification opinion. The five-year cash-only wind-down is a model assumption; real closure would require settlement of liabilities and applicable corporate procedures.')

page('Two markets, one auditable cash trail',3,'incentives and governance')
table([['Stage','Flow and evidence required'],['1. Rights and capital','Licensor grants documented rights; investors capitalize issuer through an eligible route. An independent review reconciles rights, conflicts and use of proceeds.'],['2. Commercial market','Brands book sponsorship inventory. Customers buy merchandise, content or event access. Customer payments are ordinary business revenue, not investor deposits.'],['3. Operating ledger','Issuer reconciles contracts, invoices, collections, fulfillment, fees, taxes and cash. Distributions follow available resources and board-approved policy.'],['4. Securities market','If permitted, investors transfer issuer shares through an authorized intermediary or venue. Secondary sale proceeds go to sellers, not automatically to the issuer or player.'],['5. Reporting feedback','Observed conversion, margins and collected cash update forecasts. Trading prices provide a separate market signal; price movements do not create operating revenue.']],[116,388])
h('A concrete three-party arrangement')
p('The player supplies rights and agreed services. The public supplies risk capital and can separately be customers. A team, league or other owner can earn negotiated licensing revenue only for rights it actually supplies. No NBA or team agreement exists for this project. An initial pilot can use only individually cleared categories, with no team marks or game footage.')
p('NBPA commercial licensing channels include THINK450 and the PLYRS UNTD brand launched in June 2026. Collective uses need separate rights analysis. The NBA/NBPA Fanatics partnership illustrates that league and player permissions can be distinct. [2, 3, 5] NBA/team marks, footage and commercial statistics uses require separate rights review. [4]')
h('Conflict controls that make the proposition investable')
p('Proposed controls include an independent director or conflicts committee, documented related-party pricing, restricted access to nonpublic information, published revenue recognition and cash reconciliation, and shareholder approval for material license amendments. The initial price must not rely solely on the seller\'s own optimistic forecast.')
note('No investor receives a vote on playing time, trades, rehabilitation or personal choices. A consumer purchase confers product rights; an equity purchase confers only the rights stated in its governing documents.')

page('Model the business before the stock',4,'stochastic design')
p(f'The commercial model uses {m["draws"]:,} paired Monte Carlo scenarios, seed {m["seed"]}, six fictional ventures and 20 quarterly cash-flow periods. Common demand creates correlation. Athlete-specific demand, attention events and availability create dispersion. No probability is estimated from actual player data.')
table([['Input','Declared assumption'],['Revenue commitment','40% of the initial sales budget is signed sponsor minimums in years 1-2. These survive modeled injury but face a 2% annual absorbing sponsor-default hazard.'],['Uncommitted sales','Remaining sponsorship/merchandise/content/events are aggregated. Lognormal demand, profile growth and attention catalysts determine sales; channel conversion is not estimated.'],['Attention / availability','20% probability of 1.25x attention, 15% of 0.80x, otherwise 1x. Injury affects unsold sales by a 0.45 multiplier; hazard differs by fictional profile.'],['Shared uncertainty','0.65 common loading in annual demand; 0.55 shared loading in athlete demand. Correlation coefficients in final cash flows are outcomes, not these loadings.'],['Cost stack','25% athlete license/services; 5% conditional third-party rights; 30% fulfillment/marketing; 2% servicing, each applied to collected modeled sales. Fixed costs grow 3% annually.'],['Valuation','12% annual discount rate; quarterly timing. Starting reserve earns 4%. A 21% illustrative tax applies to positive quarterly pretax income.']],[113,391])
h('The sports-to-finance connection')
p('A contract renewal or strong season can change visibility and customer interest. The model represents that route through hypothetical attention and sales shocks. It does not assign salary or infer a fixed relationship between points and revenue. A real forecasting model would need consented transaction data, a frozen forecast date and out-of-time validation.')
note('This version omits working-capital receivables, channel-specific margins, seasonality, insurance, tax losses and investor taxes. The 5% rights charge is a placeholder cost, not a published league rate. All permissions remain prerequisites to selling licensed products.')

page('Cash distributions and the financing budget',5,'worked reference case')
rise=assets[0]; fund=rise['initial_funding']; rev=rise['gross_revenue']; fixed=rise['fixed_expenses']; op=rev*.38-fixed
table([['RISE deterministic sales-budget example','Annual amount'],['Gross commercial sales',f'${rev:,.0f}'],['Athlete license/services, 25%',f'(${rev*.25:,.0f})'],['Conditional rights, 5%',f'(${rev*.05:,.0f})'],['Fulfillment and marketing, 30%',f'(${rev*.30:,.0f})'],['Platform servicing, 2%',f'(${rev*.02:,.0f})'],['Fixed operating expenses',f'(${fixed:,.0f})'],['Operating profit before interest and tax',f'${op:,.0f}']],[348,156])
note('This is a deterministic illustration at the initial sales budget, not the stochastic expected result. RISE expected year-one collected sales are $'+f'{rise["expected_annual_commercial_revenue"][0]:,.0f}'+'. All figures are fictional.')
formula('quarter profit = operating profit + reserve interest - tax\ndividend = 90% x max(quarter profit, 0)\nclosing cash = opening cash + quarter profit - dividend')
p('Positive profit is 90% distributed and 10% retained in the model. Losses consume cash. If the next balance becomes negative, the issuer fails, makes no payment in that quarter and generates no later cash flows. This is an absorbing failure assumption, not a full insolvency waterfall. In practice, cash availability and lawful distribution tests constrain dividends.')
h('Upfront capital must reconcile')
formula(f'RISE equity proceeds ${fund["gross_investor_equity_proceeds"]:,.0f}\n= reserve ${fund["operating_cash_reserve"]:,.0f} + issuance ${fund["issuance_fee"]:,.0f}\n+ upfront license budget ${fund["upfront_ip_license_payment"]:,.0f}')
p('The residual is the license budget affordable at the model DCF, not evidence of the licensor\'s fair price or willingness to accept it. The ongoing 25% fee is additional compensation. Pricing and fees must be negotiated together; increasing the upfront payment cannot create investor value.')

page('Commercial equity: conditional results',6,'model output')
rows=[['Fictional issuer','DCF / unit','P05-P95 DCF','Wind-down PV*']]
for x in assets:rows.append([x['ticker'],f'${x["fair_value_per_unit"]:.2f}',f'${x["pv_p05"]:.2f}-${x["pv_p95"]:.2f}',f'{100*x["liquidation_pv_share"]:.1f}%'])
table(rows,[128,110,156,110])
note('*Share of mean DCF from the actual remaining cash distribution at quarter 20. P05-P95 are scenario percentiles, not statistical confidence intervals. Per-unit comparisons reflect different commercial budgets; higher price does not mean a better investment.')
h('Portfolio downside is not removed by six names')
p(f'A $10,000 equal-dollar purchase at each issuer\'s mean DCF has five-year discounted funding-loss VaR95 of <b>{100*port["funding_loss_var95"]:.2f}%</b> and expected shortfall95 of <b>{100*port["funding_loss_es95"]:.2f}%</b>. Here funding loss is 1 minus discounted distributions divided by purchase cost. This is not one-day trading VaR or an observed investment loss.')
p(f'In the bottom decile of the common demand factor, mean portfolio PV is <b>{100*m["common_factor_stress"]["equal_dollar_pv_change"]:.2f}%</b> below the full-sample mean. Shared consumer demand leaves a material exposure even when individual performance varies.')
h('Why a dividend yield can mislead')
p('The issuer has a finite license and winds down after five years. Part of the payout returns economic value embedded in the reserve and finite asset. The final year includes residual cash, not recurring profit. Treating that entire payment as a perpetual dividend would overvalue the company.')
h('What the 12% rate means')
p('Purchase prices equal the discounted mean of modeled distributions. Consequently mean PV divided by price is one, and the expected-cash-flow IRR reproduces the assumed 12% rate. Neither identity validates a return forecast. Investors could pay more or less, face costs, or receive very different cash flows.')
note('No historical backtest, real athlete valuation, empirical calibration or investment recommendation is implied by the displayed prices.')

page('What actually determines feasibility?',7,'sensitivity and selection')
rows=[['Paired counterfactual','Mean portfolio PV change']]
for label,key in [('Uncommitted sales -25%','commercial_sales_minus_25pct'),('Common uncommitted sales shock -30%','common_unsold_sales_shock_minus_30pct'),('Rights fee 5% to 10%','rights_fee_10pct'),('Injury in every modeled year','injury_every_year'),('Discount rate 12% to 14%','discount_rate_0.14')]:rows.append([label,f'{100*sens[key]["equal_dollar_portfolio_pv_change"]:+.2f}%'])
table(rows,[332,172])
p('The same random draws are reused for each sensitivity so differences primarily reflect the changed assumption. Sales stresses reduce the uncommitted portion; signed minimums remain subject to sponsor default. The all-years injury case is deliberately severe, not a probability forecast.')
h('Three financing conclusions from the model')
p('<b>Rights economics are material.</b> A five-percentage-point increase in the rights cost has a larger PV impact than a two-point discount-rate change. Negotiable unit economics can matter more than elegant pricing mathematics.')
p('<b>Reserve protection costs capital.</b> Doubling reserve raises modeled equity value because more cash is present. That is not free value creation: it consumes proceeds that otherwise fund the license. Reserve sensitivity must be assessed together with the licensor\'s acceptable payment and the price investors pay.')
p(f'<b>Failure rates depend on optimistic operating simplifications.</b> REBOUND has a {100*assets[-1]["five_year_insolvency_probability"]:.3f}% baseline simulated cash-exhaustion rate; halving its reserve increases it to {100*sens["reserve_half"]["insolvency_probabilities"]["REBOUND"]:.3f}%. Zero failures in another archetype\'s sample do not establish safety.')
h('Selection risk can undermine an apparently attractive deal')
p('Players or licensors with weaker private expectations may be most willing to sell long-term exposure. A buyer must examine signed contracts, renewal exclusions, historical refunds, concentration, fulfillment capacity and related-party payments. A higher required return can compensate for uncertainty, but cannot cure missing or unenforceable rights.')

page('Platform economics without trading hype',8,'operating model')
p('Court Capital\'s first operating hypothesis is a paid commercial ledger and servicing platform for agencies and licensed ventures. It would reconcile revenue, monitor rights expiry, produce scenario reports and prepare diligence packages. Transaction-dependent compensation is a later, separately reviewed business, not a prerequisite to the initial software product.')
rows=[['Illustrative mature scale*','25 issuers','75 issuers']]
selected=[next(s for s in biz['scenarios'] if s['issuers']==n and s['annual_turnover']==1) for n in [25,75]]
for label,key in [('Recurring servicing','annual_servicing_revenue'),('Trading, one turnover','annual_trading_revenue'),('Annual platform costs','annual_operating_cost'),('Recurring operating result','recurring_operating_result'),('One-time issuance fees','one_time_issuance_revenue')]:rows.append([label]+[f'${s[key]/1e6:,.3f}m' for s in selected])
table(rows,[244,130,130])
note('*All are scale scenarios, not forecasts or traction. Equal mix of six fictional issuers, 20% active float, 5 bps transaction fee, $2.4m annual fixed budget and $15,000 cost per issuer. Servicing equals 2% of modeled collected sales. Separate software subscription pricing remains unvalidated.')
h('Break-even does not require high turnover in this scenario')
be=b.get('recurring_break_even_issuers_without_trading',29)
p(f'Average modeled annual servicing is ${b["average_annual_collected_servicing_per_issuer"]:,.0f} per issuer. With the stated cost assumptions, servicing alone reaches recurring break-even at <b>{be} issuers</b>. At 25 issuers, one annual turnover produces only ${selected[0]["annual_trading_revenue"]:,.0f}. The proposal should therefore be judged on commercial operation and retention, not speculative trading volume.')
h('Do not count launch fees as annual earnings')
p('The 2% issuance fee occurs at the initial financing. It cannot support a steady-state forecast without separately justified new issuance. The model also excludes incremental launch legal/broker costs beyond its simple fee assumption, and it may understate compliance, acquisition, insurance and staffing expense. These require vendor quotes before a financing plan is credible.')
h('Market sizing is a research task')
p('Do not multiply all NBA fans by an assumed investment ticket to create a TAM. Build a bottom-up serviceable market from willing rights owners, eligible issuers, contracted commercial revenue and verified budgets. Count investors only after suitability, jurisdiction, eligibility and demonstrated willingness to participate are considered.')

page('Prior art and a narrower differentiation',9,'competitive landscape')
table([['Primary-source precedent','Implication for Court Capital'],['Fantex, 2014-2015 [6, 7]','Issuer tracking shares linked to athlete brand-income agreements already existed. Neither athlete-linked investment nor tracking stock is a new invention.'],['Vestible, 2025 annual report [8]','Describes series tied to athlete professional earnings and team financing events. Athlete-series definition excludes endorsement/NIL income. Sports-focused public investment is an existing category.'],['Finlete, Form C [9]','Future professional earnings participation with promotional rights is another precedent. An athlete partnership and fan engagement alone do not create differentiation.'],['Socios, current planned product [10]','Advertises tokenized minority club ownership, identified as under development. Sports equity is not an unoccupied category; planned products are not proof of operating liquidity.']],[198,306])
h('A proposition that can be tested')
p('<b>Finance a bounded commercial program and make every valuation change traceable to rights, contracts, conversion, costs and cash.</b> Court Capital\'s intended contribution is the shared evidence chain across the commercial market and the investor market. A rights inventory shows what can legally be sold. A commitment ledger separates signed sponsor revenue from optimistic future sales. A distribution bridge reconciles cash to equity value.')
h('The proposed operating advantage')
p('Agencies and brands may benefit from reusable contract categories, comparable reporting and a standard diligence package across issuers. Investors may benefit from clearer cost and selection risk. Those advantages are hypotheses. They must beat the current alternatives in reconciliation time, reporting reliability, cost and forecast calibration.')
h('What would disprove distinctiveness')
p('If agencies already obtain equivalent rights-linked reporting at lower cost, or existing platforms can reproduce the workflow without measurable disadvantage, the concept has limited differentiation. This research is not a patent or freedom-to-operate search, and no claim of global first or uncopyable technology is made.')
note('SEC-filed competitor documents describe their own businesses and risks. Filing is not government endorsement, proof of success, or permission to replicate another issuer\'s structure.')

page('A practical path from prototype to business',10,'commercial milestones')
table([['Stage','Deliverable and proposed decision gate'],['Discovery','Interview 10 agencies/licensors and 10 sponsor buyers. Verify three distinct reporting or financing problems. No assumed interest from responses that merely praise the idea.'],['Paid operating pilot','Secure three rights-cleared design partners and reconcile their actual commercial ledgers. Seek paid software/service agreements independent of investment sales.'],['Evidence gate','Target 100% traceability of modeled signed receipts to contracts, no unexplained cash differences, and at least 30% reduction in reporting time against each partner\'s baseline. These are targets, not results.'],['Issuer feasibility','Obtain rights opinions, cap table, conflicts policy, independent financial review, customer concentration analysis, cost quotes and an executable operating plan.'],['Financing / liquidity','Only after eligibility, disclosures and authorized partners are established, evaluate an offering and separately assess secondary transfer. Stop if economics depend on unavailable liquidity.']],[122,382])
h('Offering routes are options to evaluate, not approvals')
p('Every securities offer or sale needs registration or an available exemption. Regulation A Tier 2 permits eligible offerings up to $75m in 12 months, with audited financial statements and ongoing reporting. Regulation Crowdfunding has its own eligibility, intermediary and disclosure requirements and generally restricts resale for one year. Neither route makes a liquid secondary market automatic. [11-13]')
p('A real market would need a chosen broker-dealer/venue structure, recordkeeping and transfer arrangements, custody or other appropriate asset-control design, independent reporting and surveillance. An ATS registers as a broker-dealer and files Form ATS; filing does not mean SEC approval. The operational and financial costs remain unquoted. [14]')
h('Rights and cap review stays separate')
p('Team-linked sponsors and related-party investment opportunities require specific review. CBA anti-circumvention provisions can reach arrangements described as non-basketball services. Paying a stated royalty does not settle those issues or grant permission to use collective player rights. [1-3]')
note('The public demonstration is software with fictional instruments. Production trading, custody, securities issuance and derivatives are separate projects requiring eligible structures and partners; none is enabled by a working interface.')

page('Market mechanics: what the lab demonstrates',11,'execution and accounting')
table([['Mechanic','Implemented research convention'],['Spot / limits','Finite three-level depth, bid/ask spreads, partial fills and FIFO limit priority. Reserved margin prevents reuse of capital committed to resting orders. Limits can remain unfilled. [16]'],['Shorts / funding','Finite locates, restricted short proceeds, borrow charges and dividend liabilities. Initial equity 50% and maintenance 30% of gross exposure are house teaching assumptions. [17-19]'],['Futures','Discrete scheduled-distribution carry reference, daily cash variation and final spot convergence; quantities in individual underlying units. [21, 22]'],['Long European options','Full premium, explicit pricing rate/volatility, 100-unit multiplier and cash intrinsic settlement at expiry. No writing. Black-Scholes uses a continuous-yield approximation. [23, 24]'],['Cash / corporate actions','Separate free cash, restricted proceeds, debt and equity. Split accounting preserves value and blocks splits with open derivatives or orders. Distributions and final cash are accounted for separately.'],['Market controls','10% limit-price collar; margin breach cancels orders and invokes a stylized adverse-price liquidation auction. No claim of production surveillance or guaranteed liquidity.']],[117,387])
h('Where the simulation differs from a real venue')
p('The local ledger uses T+0 settlement; covered U.S. securities commonly settle T+1. Regulation T generally uses 50% initial margin for marginable stock, while FINRA\'s general long maintenance minimum is 25%; short and instrument rules differ. The simplified 30% gross-exposure rule is not a regulatory replica. [17, 18, 20]')
p('Synthetic quotes are not jointly arbitrage-free with the DCF. Quote-only injury and growth shocks leave the cash scenario unchanged. If a realized payout exceeds quoted value, a separately logged information revaluation precedes the exact cash transfer. This is a modeling convention, not earned profit. Option pricing is approximate; the liquidation auction assumes execution beyond ordinary displayed depth.')
note('Shorts, futures and options are demonstration instruments. Their real availability, classification, counterparties, permissions and marginability are not established. No live broker, clearinghouse or custodian is connected.')

page('Research standards and decision questions',12,'validation and ethics')
table([['Falsifiable question','Required evidence or rejection test'],['Does performance explain sales?','Compare a contract-only forecast with added public performance/attention inputs on future held-out commercial revenue. Reject added complexity if accuracy or calibration does not improve.'],['Do signed floors protect investors?','Measure sponsor-default concentration and cash-shortfall rates. Reject the protection claim if correlated sponsor stress eliminates the benefit.'],['Does disclosure reduce selection risk?','Test valuation dispersion and error with/without verified commitments and conflicts. Stated confidence alone is not improvement.'],['Can servicing support the business?','Compare paid renewal, acquisition cost and delivery cost to the model. Reject scale economics if recurring contribution cannot fund operations.'],['Can investors obtain liquidity?','Measure actual eligible transfer completion, spread and time-to-sale in an authorized pilot. A quote or sign-up does not count as execution.']],[220,284])
h('Evidence completed')
p('Verified on October 7, 2026: 13 commercial-model checks and 24 market-engine tests passed. The separate salary appendix previously passed 12 checks. Commercial tests cover seeded draws, absorbing failure, funding reconciliation, signed-floor protection, rate/fee monotonicity and exactly-once terminal cash. Engine checks cover ledger, execution, borrowing, derivatives and information revaluation. These validate implementation properties, not demand, rights or forecast accuracy.')
h('Player welfare and market integrity')
p('Use licensed, consented commercial data and public sports information with provenance. Exclude nonpublic medical details. Proposed controls include conflict disclosures, restricted-person lists, trading windows, surveillance and volatility interruptions. Investor returns must not influence player medical or employment choices.')
h('What the portfolio project demonstrates')
p('Institutional research changed the product design. The work connects operating finance, correlated simulation, equity valuation, funding reconciliation and market accounting. Author: Aneesh Warrier, with AI-assisted research and implementation. No trained AI predictor, athlete partner, participant study or realized track record is claimed.')

for first,last,n in [(0,12,13),(12,24,14)]:
    page('Primary sources and provenance',n,'references')
    note('Accessed October 7, 2026. Source dates shown where available. Institutional claims use primary sources; operating assumptions and simulation parameters are original fictional scenarios.')
    for i in range(first,last):
        title,desc,url=SOURCES[i]
        add(f'<b>[{i+1}] <link href="{html.escape(url,quote=True)}" color="#165d89">{html.escape(title)}</link>.</b> {html.escape(desc)}','small')
    if n==14:
        h('Artifact provenance')
        note('Commercial model: version '+m['version']+'; seed '+str(m['seed'])+'; '+f'{m["draws"]:,}'+' draws. Model digest: '+hashlib.sha256((BASE/'data/commercial_model.json').read_bytes()).hexdigest()[:24]+'.')
        note('Primary citations support the rule or precedent described, not the hypothetical feasibility of this issuer. This document is a research and business-design artifact, not an investment solicitation or legal opinion.')

def footer(c,doc):
    c.saveState();w,hh=doc.pagesize;c.setStrokeColor(LINE);c.setLineWidth(.5);c.line(54,44,w-54,44)
    c.setFont('CCSans',8);c.setFillColor(GRAY);c.drawString(54,30,'COURT CAPITAL  |  Commercial venture research  |  Fictional scenarios')
    c.drawRightString(w-54,30,f'{doc.page:02d}');c.restoreState()
doc=SimpleDocTemplate(str(OUT),pagesize=(612,792),leftMargin=54,rightMargin=54,topMargin=49,bottomMargin=61,title='Court Capital | Player Enterprise Exchange',author='Aneesh Warrier',subject='Commercial venture business architecture and financial feasibility')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
from pypdf import PdfReader
r=PdfReader(str(OUT));text='\n\n'.join(f'PAGE {i+1}\n'+(x.extract_text() or '') for i,x in enumerate(r.pages))
(REPORT/'Court_Capital_Research_and_Pitch.txt').write_text(text)
(REPORT/'sources.json').write_text(json.dumps([{'id':i,'title':t,'description':d,'url':u} for i,(t,d,u) in enumerate(SOURCES,1)],indent=2))
qa={'pdf':str(OUT),'pages':len(r.pages),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'model_sha256':hashlib.sha256((BASE/'data/commercial_model.json').read_bytes()).hexdigest(),'links':sum(len(x.get('/Annots',[])) for x in r.pages),'visual_review':'pending'}
(REPORT/'qa.json').write_text(json.dumps(qa,indent=2));print(json.dumps(qa,indent=2))
